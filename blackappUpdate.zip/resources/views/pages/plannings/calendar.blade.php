@php

use Carbon\Carbon;

@endphp
              <div class="box box-primary">
                <div class="box-body no-padding">
                  <!-- THE CALENDAR -->
                  <div id="calendar"></div>
                </div>
                <!-- /.box-body -->
              </div>

<!-- Add calendarJsFile -->
@include('pages.plannings.calendarJs')
<!-- / Add calendarJsFile -->